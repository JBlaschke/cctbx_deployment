# Author:  Lisandro Dalcin
# Contact: dalcinl@gmail.com
"""Entry-point for ``python -m mpi4py ...``."""
from .run import main

if __name__ == '__main__':
    main()
